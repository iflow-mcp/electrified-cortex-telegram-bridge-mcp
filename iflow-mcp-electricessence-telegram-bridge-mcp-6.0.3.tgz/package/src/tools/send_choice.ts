import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import {
  toResult, toError, validateText, resolveChat, validateCallbackData, LIMITS,
} from "../telegram.js";
import { registerCallbackHook } from "../message-store.js";
import { requireAuth } from "../session-gate.js";
import {
  sendChoiceMessage, ackAndEditSelection, type KeyboardOption,
} from "./button-helpers.js";
import { TOKEN_SCHEMA } from "./identity-schema.js";
import { validateButtonSymbolParity } from "../button-validation.js";

const DESCRIPTION =
  "Non-blocking one-shot keyboard — sends a message with choice buttons and " +
  "returns immediately with a message_id. The first button press is auto-locked: " +
  "the keyboard is removed and the callback_query is answered automatically. " +
  "The callback_query event still appears in dequeue so the agent can read " +
  "which option was picked at its own pace. " +
  "Use choose for blocking single-selection (waits for the press). " +
  "For a blocking yes/no or multi-option selection, use confirm or choose. Requires an active session token.";

const optionSchema = z.object({
  label: z
    .string()
    .describe(
      `Button label. Keep under ${LIMITS.BUTTON_DISPLAY_MULTI_COL} chars for 2-col layout, ` +
      `or ${LIMITS.BUTTON_DISPLAY_SINGLE_COL} chars for single-column. ` +
      `API hard limit is ${LIMITS.BUTTON_TEXT} chars.`,
    ),
  value: z
    .string()
    .describe(`Callback data returned when pressed (max ${LIMITS.CALLBACK_DATA} bytes)`),
  style: z
    .enum(["success", "primary", "danger"])
    .optional()
    .describe("Button color: success (green), primary (blue), danger (red). Omit for default."),
});

export type ChoiceOption = { label: string; value: string; style?: "success" | "primary" | "danger" };

export async function handleSendChoice({
  text, options, columns = 2, parse_mode = "Markdown", disable_notification,
  reply_to, ignore_parity, token,
}: {
  text: string;
  options: ChoiceOption[];
  columns?: number;
  parse_mode?: "Markdown" | "HTML" | "MarkdownV2";
  disable_notification?: boolean;
  reply_to?: number;
  ignore_parity?: boolean;
  token: number;
}) {
  const _sid = requireAuth(token);
  if (typeof _sid !== "number") return toError(_sid);
  const chatId = resolveChat();
  if (typeof chatId !== "number") return toError(chatId);

  const textErr = validateText(text);
  if (textErr) return toError(textErr);

  // Validate button symbol parity
  if (!ignore_parity) {
    const parity = validateButtonSymbolParity(options.map((o) => o.label));
    if (!parity.ok) {
      return toError({
        code: "BUTTON_SYMBOL_PARITY" as const,
        message: `Button labels are inconsistent: ${parity.withEmoji.length} of ${options.length} have emoji. Either add emoji to all labels or remove them. Pass ignore_parity: true to send anyway.`,
        labels_with_emoji: parity.withEmoji,
        labels_without_emoji: parity.withoutEmoji,
      });
    }
  }

  // Validate options — same rules as choose
  const displayMax = columns >= 2
    ? LIMITS.BUTTON_DISPLAY_MULTI_COL
    : LIMITS.BUTTON_DISPLAY_SINGLE_COL;
  for (const opt of options) {
    const dataErr = validateCallbackData(opt.value);
    if (dataErr) return toError(dataErr);
    if (opt.label.length > LIMITS.BUTTON_TEXT) {
      return toError({
        code: "BUTTON_LABEL_EXCEEDS_LIMIT" as const,
        message: `Button label "${opt.label}" is ${opt.label.length} chars; hard limit is ${LIMITS.BUTTON_TEXT}.`,
      });
    }
    if (opt.label.length > displayMax) {
      return toError({
        code: "BUTTON_LABEL_TOO_LONG" as const,
        message:
          `Button label "${opt.label}" (${opt.label.length} chars) will be cut off on mobile. ` +
          `With columns=${columns}, keep labels under ${displayMax} chars.`,
      });
    }
  }

  const replyTo = reply_to;

  try {
    const messageId = await sendChoiceMessage(chatId, {
      text,
      options: options as KeyboardOption[],
      columns,
      parseMode: parse_mode,
      disableNotification: disable_notification,
      replyToMessageId: replyTo,
    });

    // Register one-shot auto-lock: on first press, dismiss the spinner and
    // collapse the message to show the selected option. The callback_query event
    // is still enqueued normally.
    // ownerSid tracks the session so teardown can replace the hook with a "Session closed" ack.
    registerCallbackHook(messageId, (evt) => {
      const qid = evt.content.qid;
      const matched = options.find((o) => o.value === evt.content.data);
      const label = matched?.label ?? evt.content.data ?? "?";
      void ackAndEditSelection(chatId, messageId, text, label, qid);
    }, _sid);

    return toResult({ message_id: messageId });
  } catch (err) {
    return toError(err);
  }
}

export function register(server: McpServer) {
  server.registerTool(
    "send_choice",
    {
      description: DESCRIPTION,
      inputSchema: {
        text: z.string().describe("Message text — the question or prompt shown above the buttons"),
        options: z
          .array(optionSchema)
          .min(2)
          .max(8)
          .describe("2–8 options. Laid out per the columns setting."),
        columns: z
          .number()
          .int()
          .min(1)
          .max(4)
          .default(2)
          .describe("Buttons per row (default 2)"),
        parse_mode: z
          .enum(["Markdown", "HTML", "MarkdownV2"])
          .default("Markdown")
          .describe("Markdown = auto-converted (default); MarkdownV2 = raw; HTML = HTML tags"),
        disable_notification: z
          .boolean()
          .optional()
          .describe("Send silently (no sound/notification)"),
        reply_to: z
          .number()
          .int()
          .min(1)
          .optional()
          .describe("Reply to this message ID"),
        ignore_parity: z
          .boolean()
          .optional()
          .describe("Set true to bypass button label emoji-consistency check"),
              token: TOKEN_SCHEMA,
},
    },
    handleSendChoice,
  );
}
